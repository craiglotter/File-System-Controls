Public Class frm_Sound
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.

    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnFile = New System.Windows.Forms.Button
        Me.btnEmbed = New System.Windows.Forms.Button
        Me.btnSystem = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'btnFile
        '
        Me.btnFile.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnFile.Location = New System.Drawing.Point(16, 16)
        Me.btnFile.Name = "btnFile"
        Me.btnFile.Size = New System.Drawing.Size(264, 23)
        Me.btnFile.TabIndex = 0
        Me.btnFile.Text = "Wave From File"
        '
        'btnEmbed
        '
        Me.btnEmbed.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnEmbed.Location = New System.Drawing.Point(16, 96)
        Me.btnEmbed.Name = "btnEmbed"
        Me.btnEmbed.Size = New System.Drawing.Size(264, 23)
        Me.btnEmbed.TabIndex = 1
        Me.btnEmbed.Text = "Embedded Wave"
        '
        'btnSystem
        '
        Me.btnSystem.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnSystem.Location = New System.Drawing.Point(16, 56)
        Me.btnSystem.Name = "btnSystem"
        Me.btnSystem.Size = New System.Drawing.Size(264, 23)
        Me.btnSystem.TabIndex = 2
        Me.btnSystem.Text = "System Wave"
        '
        'frm_Sound
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(304, 142)
        Me.Controls.Add(Me.btnFile)
        Me.Controls.Add(Me.btnSystem)
        Me.Controls.Add(Me.btnEmbed)
        Me.Name = "frm_Sound"
        Me.Text = "Sound Test"
        Me.ResumeLayout(False)

    End Sub

#End Region


    Friend WithEvents btnSystem As System.Windows.Forms.Button
    Friend WithEvents btnEmbed As System.Windows.Forms.Button
    Friend WithEvents btnFile As System.Windows.Forms.Button

    Private Sub btnFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFile.Click
        'File Located in executable dir, change it if you need
        Sound.PlayWaveFile("sn01088a.wav")
    End Sub

    Private Sub btnEmbed_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEmbed.Click
        'Remeber to include the wyve in the project and then in the "build action"
        'properties set it as: "Embedded Resource"
        Sound.PlayWaveResource("The Microsoft Sound.wav")
    End Sub

    Private Sub btnSystem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSystem.Click

        'Here some ...

        '"SystemQuestion"
        '"SystemExclaimation"
        '"SystemHand"
        '"Maximize"
        '"MenuCommand"
        '"MenuPopup"
        '"Minimize"
        '"MailBeep"
        '"Open"
        '"Close"
        '"AppGPFault"
        '".Default"
        '"SystemAsterisk"
        '"RestoreUp"
        '"RestoreDown"
        '"SystemExit"
        '"SystemStart"

        Sound.PlayWaveSystem("SystemExit")
    End Sub
End Class
