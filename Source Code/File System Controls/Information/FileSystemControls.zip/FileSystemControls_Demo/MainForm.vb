Imports HyperCoder.Win.FileSystemControls
Public Class MainForm
  Inherits System.Windows.Forms.Form
#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  Friend WithEvents ft As FolderTree
  Friend WithEvents LV As FileList
  Friend WithEvents txtDD As System.Windows.Forms.TextBox
  Friend WithEvents Panel1 As System.Windows.Forms.Panel
  Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
  Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
  Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
  Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
  Friend WithEvents Splitter1 As System.Windows.Forms.Splitter
  Friend WithEvents ctxMenuFolderTreeName As System.Windows.Forms.MenuItem
  Friend WithEvents ctxMenuFT As System.Windows.Forms.ContextMenu
  Friend WithEvents ctxMnuLVFile As System.Windows.Forms.ContextMenu
  Friend WithEvents ctxMnuLvFileName As System.Windows.Forms.MenuItem
  Friend WithEvents mnuFolderNewFolder As System.Windows.Forms.MenuItem
  Friend WithEvents txtFolderProps As System.Windows.Forms.TextBox
  Friend WithEvents ctxMenuFileList As System.Windows.Forms.ContextMenu
  Friend WithEvents ctxMenuFileView As System.Windows.Forms.MenuItem
  Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
  Friend WithEvents mnuFileListRefresh As System.Windows.Forms.MenuItem
  Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
  Friend WithEvents mnuSelectAll As System.Windows.Forms.MenuItem
  Friend WithEvents btnGo As System.Windows.Forms.Button
  Friend WithEvents cmbDemo As System.Windows.Forms.ComboBox
  Friend WithEvents Label1 As System.Windows.Forms.Label
  Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
  Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
  Friend WithEvents mnuFTIconsSmall As System.Windows.Forms.MenuItem
  Friend WithEvents mnuFTIconsLarge As System.Windows.Forms.MenuItem
  Friend WithEvents mnuFTExpandAll As System.Windows.Forms.MenuItem
  Friend WithEvents mnuFTRefresh As System.Windows.Forms.MenuItem
  Friend WithEvents mnuFTBeginRename As System.Windows.Forms.MenuItem
  Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.components = New System.ComponentModel.Container()
    Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(MainForm))
    Me.ft = New HyperCoder.Win.FileSystemControls.FolderTree()
    Me.ctxMenuFT = New System.Windows.Forms.ContextMenu()
    Me.mnuFTExpandAll = New System.Windows.Forms.MenuItem()
    Me.ctxMenuFolderTreeName = New System.Windows.Forms.MenuItem()
    Me.mnuFTBeginRename = New System.Windows.Forms.MenuItem()
    Me.mnuFTRefresh = New System.Windows.Forms.MenuItem()
    Me.MenuItem2 = New System.Windows.Forms.MenuItem()
    Me.mnuFolderNewFolder = New System.Windows.Forms.MenuItem()
    Me.MenuItem3 = New System.Windows.Forms.MenuItem()
    Me.MenuItem4 = New System.Windows.Forms.MenuItem()
    Me.mnuFTIconsSmall = New System.Windows.Forms.MenuItem()
    Me.mnuFTIconsLarge = New System.Windows.Forms.MenuItem()
    Me.LV = New HyperCoder.Win.FileSystemControls.FileList()
    Me.txtDD = New System.Windows.Forms.TextBox()
    Me.Panel1 = New System.Windows.Forms.Panel()
    Me.Splitter1 = New System.Windows.Forms.Splitter()
    Me.ColumnHeader1 = New System.Windows.Forms.ColumnHeader()
    Me.ColumnHeader2 = New System.Windows.Forms.ColumnHeader()
    Me.ColumnHeader3 = New System.Windows.Forms.ColumnHeader()
    Me.ColumnHeader4 = New System.Windows.Forms.ColumnHeader()
    Me.ctxMnuLVFile = New System.Windows.Forms.ContextMenu()
    Me.ctxMnuLvFileName = New System.Windows.Forms.MenuItem()
    Me.ctxMenuFileList = New System.Windows.Forms.ContextMenu()
    Me.ctxMenuFileView = New System.Windows.Forms.MenuItem()
    Me.MenuItem1 = New System.Windows.Forms.MenuItem()
    Me.mnuSelectAll = New System.Windows.Forms.MenuItem()
    Me.mnuFileListRefresh = New System.Windows.Forms.MenuItem()
    Me.txtFolderProps = New System.Windows.Forms.TextBox()
    Me.btnGo = New System.Windows.Forms.Button()
    Me.cmbDemo = New System.Windows.Forms.ComboBox()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
    Me.Panel1.SuspendLayout()
    Me.SuspendLayout()
    '
    'ft
    '
    Me.ft.AllowDrop = True
    Me.ft.AutoRename = True
    Me.ft.ContextMenu = Me.ctxMenuFT
    Me.ft.Cursor = System.Windows.Forms.Cursors.Default
    Me.ft.Dock = System.Windows.Forms.DockStyle.Left
    Me.ft.HideSelection = False
    Me.ft.ImageIndex = -1
    Me.ft.LabelEdit = True
    Me.ft.Name = "ft"
    Me.ft.SelectedImageIndex = -1
    Me.ft.Size = New System.Drawing.Size(384, 376)
    Me.ft.TabIndex = 0
    Me.ft.Text = "FolderTree"
    Me.ToolTip1.SetToolTip(Me.ft, "Right click for menu")
    '
    'ctxMenuFT
    '
    Me.ctxMenuFT.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFTExpandAll, Me.ctxMenuFolderTreeName, Me.mnuFTBeginRename, Me.mnuFTRefresh, Me.MenuItem2, Me.mnuFolderNewFolder, Me.MenuItem3, Me.MenuItem4})
    '
    'mnuFTExpandAll
    '
    Me.mnuFTExpandAll.Index = 0
    Me.mnuFTExpandAll.Text = "&Expand All"
    '
    'ctxMenuFolderTreeName
    '
    Me.ctxMenuFolderTreeName.Index = 1
    Me.ctxMenuFolderTreeName.Text = "Folder &Name"
    '
    'mnuFTBeginRename
    '
    Me.mnuFTBeginRename.Index = 2
    Me.mnuFTBeginRename.Text = "&Rename"
    '
    'mnuFTRefresh
    '
    Me.mnuFTRefresh.Index = 3
    Me.mnuFTRefresh.Text = "&Refresh"
    '
    'MenuItem2
    '
    Me.MenuItem2.Index = 4
    Me.MenuItem2.Text = "-"
    '
    'mnuFolderNewFolder
    '
    Me.mnuFolderNewFolder.Index = 5
    Me.mnuFolderNewFolder.Text = "&New Folder"
    '
    'MenuItem3
    '
    Me.MenuItem3.Index = 6
    Me.MenuItem3.Text = "-"
    '
    'MenuItem4
    '
    Me.MenuItem4.Index = 7
    Me.MenuItem4.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFTIconsSmall, Me.mnuFTIconsLarge})
    Me.MenuItem4.Text = "&View"
    '
    'mnuFTIconsSmall
    '
    Me.mnuFTIconsSmall.Index = 0
    Me.mnuFTIconsSmall.Text = "&Small Icons"
    '
    'mnuFTIconsLarge
    '
    Me.mnuFTIconsLarge.Index = 1
    Me.mnuFTIconsLarge.Text = "&Large Icons"
    '
    'LV
    '
    Me.LV.AllowDrop = True
    Me.LV.BackgroundImage = CType(resources.GetObject("LV.BackgroundImage"), System.Drawing.Bitmap)
    Me.LV.Dock = System.Windows.Forms.DockStyle.Fill
    Me.LV.FileNameBackColor = System.Drawing.Color.WhiteSmoke
    Me.LV.Folder = "L:\Documents and Settings\WdC\Desktop"
    Me.LV.FolderTree = Me.ft
    Me.LV.LabelEdit = True
    Me.LV.Location = New System.Drawing.Point(388, 0)
    Me.LV.Name = "LV"
    Me.LV.Size = New System.Drawing.Size(484, 376)
    Me.LV.Sorting = System.Windows.Forms.SortOrder.Ascending
    Me.LV.TabIndex = 6
    Me.LV.Text = "FolderTree"
    Me.ToolTip1.SetToolTip(Me.LV, "Right click and item for Menu 1. Right click the empty area for Menu 2")
    '
    'txtDD
    '
    Me.txtDD.AllowDrop = True
    Me.txtDD.Location = New System.Drawing.Point(392, 384)
    Me.txtDD.Multiline = True
    Me.txtDD.Name = "txtDD"
    Me.txtDD.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal
    Me.txtDD.Size = New System.Drawing.Size(480, 120)
    Me.txtDD.TabIndex = 10
    Me.txtDD.Text = "Drag Items Here"
    Me.txtDD.WordWrap = False
    '
    'Panel1
    '
    Me.Panel1.Controls.AddRange(New System.Windows.Forms.Control() {Me.LV, Me.Splitter1, Me.ft})
    Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
    Me.Panel1.Name = "Panel1"
    Me.Panel1.Size = New System.Drawing.Size(872, 376)
    Me.Panel1.TabIndex = 11
    '
    'Splitter1
    '
    Me.Splitter1.Location = New System.Drawing.Point(384, 0)
    Me.Splitter1.Name = "Splitter1"
    Me.Splitter1.Size = New System.Drawing.Size(4, 376)
    Me.Splitter1.TabIndex = 7
    Me.Splitter1.TabStop = False
    '
    'ColumnHeader1
    '
    Me.ColumnHeader1.Text = "Name"
    Me.ColumnHeader1.Width = 147
    '
    'ColumnHeader2
    '
    Me.ColumnHeader2.Text = "Size"
    Me.ColumnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
    Me.ColumnHeader2.Width = 73
    '
    'ColumnHeader3
    '
    Me.ColumnHeader3.Text = "Type"
    Me.ColumnHeader3.Width = 131
    '
    'ColumnHeader4
    '
    Me.ColumnHeader4.Text = "Date Modified"
    Me.ColumnHeader4.Width = 64
    '
    'ctxMnuLVFile
    '
    Me.ctxMnuLVFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.ctxMnuLvFileName})
    '
    'ctxMnuLvFileName
    '
    Me.ctxMnuLvFileName.Index = 0
    Me.ctxMnuLvFileName.Text = "File &Name"
    '
    'ctxMenuFileList
    '
    Me.ctxMenuFileList.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.ctxMenuFileView, Me.MenuItem1, Me.mnuSelectAll, Me.mnuFileListRefresh})
    '
    'ctxMenuFileView
    '
    Me.ctxMenuFileView.Index = 0
    Me.ctxMenuFileView.Text = "&View"
    '
    'MenuItem1
    '
    Me.MenuItem1.Index = 1
    Me.MenuItem1.Text = "-"
    '
    'mnuSelectAll
    '
    Me.mnuSelectAll.Index = 2
    Me.mnuSelectAll.Text = "&Select All"
    '
    'mnuFileListRefresh
    '
    Me.mnuFileListRefresh.Index = 3
    Me.mnuFileListRefresh.Text = "&Refresh"
    '
    'txtFolderProps
    '
    Me.txtFolderProps.AllowDrop = True
    Me.txtFolderProps.Location = New System.Drawing.Point(8, 384)
    Me.txtFolderProps.Multiline = True
    Me.txtFolderProps.Name = "txtFolderProps"
    Me.txtFolderProps.ReadOnly = True
    Me.txtFolderProps.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal
    Me.txtFolderProps.Size = New System.Drawing.Size(376, 88)
    Me.txtFolderProps.TabIndex = 14
    Me.txtFolderProps.Text = ""
    Me.txtFolderProps.WordWrap = False
    '
    'btnGo
    '
    Me.btnGo.Location = New System.Drawing.Point(328, 480)
    Me.btnGo.Name = "btnGo"
    Me.btnGo.Size = New System.Drawing.Size(56, 23)
    Me.btnGo.TabIndex = 15
    Me.btnGo.Text = "Go"
    '
    'cmbDemo
    '
    Me.cmbDemo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
    Me.cmbDemo.Location = New System.Drawing.Point(48, 480)
    Me.cmbDemo.Name = "cmbDemo"
    Me.cmbDemo.Size = New System.Drawing.Size(272, 21)
    Me.cmbDemo.TabIndex = 16
    '
    'Label1
    '
    Me.Label1.Location = New System.Drawing.Point(8, 480)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(40, 16)
    Me.Label1.TabIndex = 17
    Me.Label1.Text = "Demo"
    '
    'MainForm
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
    Me.ClientSize = New System.Drawing.Size(872, 509)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label1, Me.cmbDemo, Me.btnGo, Me.txtFolderProps, Me.Panel1, Me.txtDD})
    Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Name = "MainForm"
    Me.Text = "MainForm"
    Me.Panel1.ResumeLayout(False)
    Me.ResumeLayout(False)

  End Sub

#End Region
  Private m_iCheckedFileListMenuItemIndex As Integer
  Private Sub ft_AfterSelect(ByVal Sender As Object, ByVal e As AfterSelectEventArgs) Handles ft.AfterSelect
    Dim th As String = ControlChars.CrLf & "Node Type : " & System.ComponentModel.TypeDescriptor.GetConverter(e.Node.Type).ConvertToString(e.Node.Type)
    txtFolderProps.Text = "Full Path : " & e.Node.FullPath & ControlChars.CrLf & "File Path : " & e.Node.FilePath & th
  End Sub
  Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    txtDD.Text &= ControlChars.CrLf & "or drag files from windows explorer to FileList"
    cmbDemo.Items.Add("SelectItemFromFullPath")
    cmbDemo.Items.Add("SelectItemFromFilePath")
    cmbDemo.Items.Add("Selected Drive Info")
    cmbDemo.Items.Add("Stand alone FileList")
    cmbDemo.SelectedIndex = 0
    txtFolderProps.Font = New Font(Font.FontFamily.GenericMonospace, 8.0F, FontStyle.Regular)
    Dim c As Object
    Dim m As MenuItem
    Dim x As Integer
    Dim y As Integer
    y = LV.View
    For Each c In System.ComponentModel.TypeDescriptor.GetConverter(GetType(Windows.Forms.View)).GetStandardValues
      m = New MenuItem(System.ComponentModel.TypeDescriptor.GetConverter(c).ConvertToString(c))
      ctxMenuFileView.MenuItems.Add(m)
      AddHandler m.Click, AddressOf ctxMenuFileView_Click
      If x = y Then
        m.Checked = True
        m_iCheckedFileListMenuItemIndex = x
      End If
      x += 1
    Next
  End Sub
  Private Sub LV_FolderChanged(ByVal sender As Object, ByVal e As HyperCoder.Win.FileSystemControls.FolderChangedEventArgs) Handles LV.FolderChanged
    If Not LV.FolderTree Is Nothing Then
      LV.FolderTree = Nothing
    End If
  End Sub

  Private Sub LV_ItemActivate(ByVal sender As System.Object, ByVal e As HyperCoder.Win.FileSystemControls.ItemActivateEventArgs) Handles LV.ItemActivate
    txtFolderProps.Text = e.SelectedItem.FullName
  End Sub

  Private Sub LV_ItemDrag(ByVal sender As Object, ByVal e As System.Windows.Forms.ItemDragEventArgs) Handles LV.ItemDrag
    If e.Button = MouseButtons.Left Then
      If LV.SelectedItems.Count > 0 Then
        Dim FileDrop(LV.SelectedItems.Count - 1) As String
        Dim x As Integer
        Dim li As FileListItem
        For x = 0 To LV.SelectedItems.Count - 1
          li = LV.SelectedItems(x)
          FileDrop(x) = li.FullName
        Next
        DoDragDrop(FileDrop, DragDropEffects.Copy)
      End If
    End If
  End Sub

  Private Sub TxtDD_DragOver(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles txtDD.DragOver
    e.Effect = DragDropEffects.Copy
  End Sub
  Private Sub TextDD_DragDrop(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles txtDD.DragDrop
    Dim files() As String
    Dim x As Integer
    files = CType(e.Data.GetData(DataFormats.FileDrop), String())
    If files Is Nothing Then
      files = CType(e.Data.GetData("System.String[]"), String())
    End If
    If Not files Is Nothing Then
      txtDD.Text = ""
      For x = 0 To files.GetUpperBound(0)
        txtDD.Text &= files(x) & ControlChars.CrLf
      Next
    End If
  End Sub

  Private Sub ft_ItemDrag(ByVal sender As Object, ByVal e As System.Windows.Forms.ItemDragEventArgs) Handles ft.ItemDrag
    If e.Button = MouseButtons.Left Then
      Dim FileDrop() As String = {ft.SelectedNode.FilePath}
      DoDragDrop(FileDrop, DragDropEffects.Copy)
    End If
  End Sub

  Private Sub LV_DragOver(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles LV.DragOver
    e.Effect = DragDropEffects.Copy
  End Sub

  Private Sub LV_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles LV.DragDrop
    Dim files() As String
    Dim x As Integer
    Dim sPath As String = LV.Folder
    Dim sTarget As String
    If Not sPath.EndsWith("\") Then
      sPath &= "\"
    End If
    files = CType(e.Data.GetData(DataFormats.FileDrop), String())
    If files Is Nothing Then
      files = CType(e.Data.GetData("System.String[]"), String())
    End If
    If Not files Is Nothing Then
      Dim m As MessageBox
      If m.Show("This demo will actually copy the selected files." & ControlChars.CrLf & ControlChars.CrLf & "Are you sure you want continue ?", "Demo", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = DialogResult.Yes Then
        For x = 0 To files.GetUpperBound(0)
          sTarget = files(x).Substring(files(x).LastIndexOf("\") + 1)
          IO.File.Copy(files(x), sPath & sTarget)
          ' you can use the following method to add items to the list, but this is not recommended
          ' instead you should call the Refresh method at the and of the operations.
          'LV.Items.Add(LV.CreateItem(sPath & sTarget, "",  "", FileListItem.ItemTypes.File))
        Next
        LV.Refresh()
      End If
    End If
  End Sub

  Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    ft.Refresh(ft.SelectedNode)
  End Sub
  Private Sub lblSelFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    LV.Folder = ""
  End Sub

  Private Sub ctxMenuFolderTreeName_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ctxMenuFolderTreeName.Click
    MsgBox(_tvRightClickNode.FilePath)

  End Sub
  Private _tvRightClickNode As FolderTreeNode
  Private Sub ft_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ft.MouseUp
    If e.Button = MouseButtons.Right Then
      _tvRightClickNode = CType(ft.GetNodeAt(e.X, e.Y), FolderTreeNode)
    End If
  End Sub
  Private _lvRightClickNode As FileListItem

  Private Sub LV_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles LV.MouseDown
    If e.Button = MouseButtons.Right Then
      _lvRightClickNode = CType(LV.GetItemAt(e.X, e.Y), FileListItem)
      If _lvRightClickNode Is Nothing Then
        LV.ContextMenu = ctxMenuFileList
        Exit Sub
      End If
      Select Case _lvRightClickNode.Type
        Case FileListItem.ItemTypes.Folder
          LV.ContextMenu = Nothing
        Case FileListItem.ItemTypes.File
          LV.ContextMenu = ctxMnuLVFile
        Case Else
          LV.ContextMenu = Nothing
      End Select
    End If
  End Sub

  Private Sub ctxMnuLvFileName_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ctxMnuLvFileName.Click
    If Not _lvRightClickNode Is Nothing Then
      MsgBox(_lvRightClickNode.FullName)
    End If
  End Sub

  Private Sub mnuFolderNewFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFolderNewFolder.Click
    ' when creating, deleting folders
    ' you should perform those file functions first then call the refresh(thisnode) method
    ' of the folder tree
    Dim sAppend As String = ""
    Dim x As Integer = 1
    Do Until Not IO.Directory.Exists(_tvRightClickNode.FilePath & "\New Folder" & sAppend)
      x += 1
      sAppend = " (" & x.ToString & ")"
    Loop
    IO.Directory.CreateDirectory(_tvRightClickNode.FilePath & "\New Folder" & sAppend)
    ft.Refresh(_tvRightClickNode)
    ft.SelectNodeFromFullPath(_tvRightClickNode.FullPath & "\New Folder" & sAppend)
    ft.SelectedNode.BeginEdit()
  End Sub
  Private Sub ctxMenuFileView_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    Dim m As MenuItem = CType(sender, MenuItem)
    ctxMenuFileView.MenuItems(m_iCheckedFileListMenuItemIndex).Checked = False
    Select Case m.Text
      Case "Details"
        LV.View = View.Details
      Case "LargeIcon"
        LV.View = View.LargeIcon
      Case "List"
        LV.View = View.List
      Case "SmallIcon"
        LV.View = View.SmallIcon
    End Select
    m.Checked = True
    m_iCheckedFileListMenuItemIndex = m.Index
  End Sub

  Private Sub mnuFileListRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileListRefresh.Click
    LV.Refresh()
  End Sub

  Private Sub mnuSelectAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuSelectAll.Click
    LV.SelectAll()
  End Sub

  Private Sub btnGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGo.Click
    Dim sFile As String
    Dim c As Char
    Dim sLabel As String
    Dim sysFold As String
    Select Case cmbDemo.SelectedIndex
      Case 0
        Dim d As New DriveInfo()
        sysFold = Environment.GetFolderPath(Environment.SpecialFolder.System)
        c = sysFold.Chars(0)
        sLabel = d(c).VolumeLabel()
        sFile = "Desktop\My Computer\" & sLabel & " (" & c & ":)" & sysFold.Substring(2) & "\com"
        sFile = InputBox("This demo assumes the rootFolder is 'Desktop' and system language is English." & ControlChars.CrLf & "This demo will select the following item.", "Demo", sFile)
        ft.SelectNodeFromFullPath(sFile)
      Case 1
        sFile = Environment.GetFolderPath(Environment.SpecialFolder.System) & "\com"
        sFile = InputBox("This demo will select the following folder.", "Demo", sFile)
        If sFile.Trim <> "" Then
          ft.SelectNodeFromFilePath(sFile)
        End If
      Case 2
        ft.SelectNodeFromIndex(0)
        Dim d As DriveInfo.Drive = ft.SelectedDrive
        Dim sInfo As String = _
            "   Volume Label :" & d.VolumeLabel & ControlChars.CrLf & _
            "  Serial Number :" & d.Serial & ControlChars.CrLf & _
            "    File System :" & d.FileSystem & ControlChars.CrLf & _
            "     Drive Size : " & d.DriveSize.tostring & ControlChars.CrLf & _
            "Available Space :" & d.AvailableSpace.ToString & ControlChars.CrLf & _
            "     Free Space : " & d.FreeSpace.tostring & ControlChars.CrLf & _
            "     Drive Type :" & d.DriveType.ToString & ControlChars.CrLf
        Dim f As New Form()
        f.Size = New Drawing.Size(300, 200)
        Dim txt As New TextBox()
        Dim b As New Button()
        b.Text = "OK"
        b.DialogResult = DialogResult.OK
        txt.Font = New Font(Font.FontFamily.GenericMonospace, 8.0F, FontStyle.Regular)
        txt.Multiline = True
        txt.Text = sInfo
        b.Dock = DockStyle.Bottom
        txt.Dock = DockStyle.Fill
        f.StartPosition = FormStartPosition.CenterParent
        f.Controls.Add(b)
        f.AcceptButton = b
        f.Controls.Add(txt)
        f.ShowDialog()
        txt.Dispose()
        f.Dispose()
      Case 3
        LV.FolderTree = Nothing
        LV.Folder = ""
        LV.ShowFolders = True
    End Select
  End Sub

  Private Sub mnuFTIconsSmall_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFTIconsSmall.Click
    mnuFTIconsSmall.Checked = True
    mnuFTIconsLarge.Checked = False
    ft.IconSize = FolderTree.IconSize2Display.Small
  End Sub

  Private Sub mnuFTIconsLarge_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFTIconsLarge.Click
    mnuFTIconsSmall.Checked = False
    mnuFTIconsLarge.Checked = True
    ft.IconSize = FolderTree.IconSize2Display.Large
  End Sub

  Private Sub mnuFTExpandAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFTExpandAll.Click
    _tvRightClickNode.ExpandAll()
  End Sub

  Private Sub mnuFTRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFTRefresh.Click
    ft.Refresh(_tvRightClickNode)
  End Sub

  Private Sub mnuFTBeginRename_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFTBeginRename.Click
    _tvRightClickNode.BeginEdit()
  End Sub
End Class
